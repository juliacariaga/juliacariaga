 from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity

from models import db, Formulario

formularios_bp = Blueprint("formularios_bp", __name__, url_prefix="/formularios")


# ---------- POST /formularios/ — Cadastrar formulário (já existente no projeto original) ----------
@formularios_bp.route("/", methods=["POST"])
@jwt_required()
def cadastrar_formulario():
    usuario_id = get_jwt_identity()
    dados = request.get_json() or {}

    titulo = dados.get("titulo")
    descricao = dados.get("descricao")

    if not titulo:
        return jsonify({"erro": "O campo 'titulo' é obrigatório."}), 400

    novo_formulario = Formulario(
        titulo=titulo,
        descricao=descricao,
        usuario_id=usuario_id
    )

    db.session.add(novo_formulario)
    db.session.commit()

    return jsonify({
        "mensagem": "Formulário cadastrado com sucesso.",
        "formulario": novo_formulario.to_dict()
    }), 201


# ---------- GET /formularios/<id> — Consultar formulário ----------
@formularios_bp.route("/<int:formulario_id>", methods=["GET"])
@jwt_required()
def consultar_formulario(formulario_id):
    formulario = Formulario.query.get(formulario_id)

    if not formulario:
        return jsonify({"erro": "Formulário não encontrado."}), 404

    return jsonify({"formulario": formulario.to_dict()}), 200


# ---------- PUT /formularios/<id> — Atualizar formulário ----------
@formularios_bp.route("/<int:formulario_id>", methods=["PUT"])
@jwt_required()
def atualizar_formulario(formulario_id):
    formulario = Formulario.query.get(formulario_id)

    if not formulario:
        return jsonify({"erro": "Formulário não encontrado."}), 404

    dados = request.get_json() or {}

    if "titulo" in dados:
        formulario.titulo = dados["titulo"]

    if "descricao" in dados:
        formulario.descricao = dados["descricao"]

    db.session.commit()

    return jsonify({
        "mensagem": "Formulário atualizado com sucesso.",
        "formulario": formulario.to_dict()
    }), 200


# ---------- DELETE /formularios/<id> — Excluir formulário ----------
@formularios_bp.route("/<int:formulario_id>", methods=["DELETE"])
@jwt_required()
def excluir_formulario(formulario_id):
    formulario = Formulario.query.get(formulario_id)

    if not formulario:
        return jsonify({"erro": "Formulário não encontrado."}), 404

    db.session.delete(formulario)
    db.session.commit()

    return jsonify({"mensagem": "Formulário excluído com sucesso."}), 200