  from flask import Flask, jsonify
from flask_jwt_extended import JWTManager

from config import Config
from models import db
from routes_users import users_bp
from routes_formularios import formularios_bp


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Inicializa extensões
    db.init_app(app)
    JWTManager(app)

    # Registra as rotas (blueprints)
    app.register_blueprint(users_bp)
    app.register_blueprint(formularios_bp)

    # Cria as tabelas do banco, caso ainda não existam
    with app.app_context():
        db.create_all()

    @app.route("/")
    def index():
        return jsonify({
            "mensagem": "API Login + Cadastro rodando com sucesso.",
            "rotas_disponiveis": {
                "usuarios": {
                    "POST /users/": "Cadastrar usuário",
                    "POST /users/login": "Login (retorna access_token)",
                    "GET /users/<id>": "Consultar usuário (JWT)",
                    "PUT /users/<id>": "Atualizar usuário (JWT)",
                    "DELETE /users/<id>": "Excluir usuário (JWT)",
                },
                "formularios": {
                    "POST /formularios/": "Cadastrar formulário (JWT)",
                    "GET /formularios/<id>": "Consultar formulário (JWT)",
                    "PUT /formularios/<id>": "Atualizar formulário (JWT)",
                    "DELETE /formularios/<id>": "Excluir formulário (JWT)",
                }
            }
        })

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5000)