 from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity

from models import db, Usuario

users_bp = Blueprint("users_bp", __name__, url_prefix="/users")


# ---------- CADASTRO (já existente no projeto original) ----------
@users_bp.route("/", methods=["POST"])
def cadastrar_usuario():
    dados = request.get_json() or {}
    nome = dados.get("nome")
    email = dados.get("email")
    senha = dados.get("senha")

    if not nome or not email or not senha:
        return jsonify({"erro": "Campos 'nome', 'email' e 'senha' são obrigatórios."}), 400

    if Usuario.query.filter_by(email=email).first():
        return jsonify({"erro": "Já existe um usuário cadastrado com esse email."}), 409

    novo_usuario = Usuario(nome=nome, email=email)
    novo_usuario.set_senha(senha)

    db.session.add(novo_usuario)
    db.session.commit()

    return jsonify({
        "mensagem": "Usuário cadastrado com sucesso.",
        "usuario": novo_usuario.to_dict()
    }), 201


# ---------- LOGIN (já existente no projeto original) ----------
@users_bp.route("/login", methods=["POST"])
def login():
    dados = request.get_json() or {}
    email = dados.get("email")
    senha = dados.get("senha")

    if not email or not senha:
        return jsonify({"erro": "Campos 'email' e 'senha' são obrigatórios."}), 400

    usuario = Usuario.query.filter_by(email=email).first()

    if not usuario or not usuario.checar_senha(senha):
        return jsonify({"erro": "Email ou senha inválidos."}), 401

    access_token = create_access_token(identity=str(usuario.id))

    return jsonify({
        "mensagem": "Login realizado com sucesso.",
        "access_token": access_token
    }), 200


# ---------- GET /users/<id> — Consultar usuário ----------
@users_bp.route("/<int:usuario_id>", methods=["GET"])
@jwt_required()
def consultar_usuario(usuario_id):
    usuario = Usuario.query.get(usuario_id)

    if not usuario:
        return jsonify({"erro": "Usuário não encontrado."}), 404

    return jsonify({"usuario": usuario.to_dict()}), 200


# ---------- PUT /users/<id> — Atualizar usuário ----------
@users_bp.route("/<int:usuario_id>", methods=["PUT"])
@jwt_required()
def atualizar_usuario(usuario_id):
    usuario = Usuario.query.get(usuario_id)

    if not usuario:
        return jsonify({"erro": "Usuário não encontrado."}), 404

    dados = request.get_json() or {}

    if "nome" in dados:
        usuario.nome = dados["nome"]

    if "email" in dados:
        # evita duplicar email de outro usuário
        existente = Usuario.query.filter_by(email=dados["email"]).first()
        if existente and existente.id != usuario.id:
            return jsonify({"erro": "Esse email já está em uso por outro usuário."}), 409
        usuario.email = dados["email"]

    if "senha" in dados and dados["senha"]:
        usuario.set_senha(dados["senha"])

    db.session.commit()

    return jsonify({
        "mensagem": "Usuário atualizado com sucesso.",
        "usuario": usuario.to_dict()
    }), 200


# ---------- DELETE /users/<id> — Excluir usuário ----------
@users_bp.route("/<int:usuario_id>", methods=["DELETE"])
@jwt_required()
def excluir_usuario(usuario_id):
    usuario = Usuario.query.get(usuario_id)

    if not usuario:
        return jsonify({"erro": "Usuário não encontrado."}), 404

    db.session.delete(usuario)
    db.session.commit()

    return jsonify({"mensagem": "Usuário excluído com sucesso."}), 200